<?php return array('dependencies' => array('bp-block-data', 'react', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-i18n', 'wp-server-side-render'), 'version' => '71f4c101ccd9738e5501');
