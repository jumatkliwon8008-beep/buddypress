<?php return array('dependencies' => array('wp-blocks', 'wp-i18n'), 'version' => 'fe1bd356553749739ab9');
